from flask import Blueprint

events = Blueprint('events', __name__)
