#!/bin/bash

echo "gcCTF{bAtchShELl}"